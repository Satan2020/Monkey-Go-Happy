var monkey, monkeyImage;
var invisibleGround;

var bananaImage, bananaGroup;
var obstacleImage, obstacleGroup;

var backImage;
var score;

function preload() {
  backImage = loadImage ("jumgle.jpg");
  monkeyImage = loadAnimation ("Monkey_01.png",    "Monkey_02.png", "Monkey_03.png", "Monkey_04.png",  "Monkey_05.png", "Monkey_06.png", "Monkey_07.png",  "Monkey_08.png", "Monkey_09.png", "Monkey_10.png");
  
  bananaImage = loadImage ("banana.png");
  obstacleImage = loadImage ("stone.png");
}

function setup() {
  createCanvas(600, 200);
  
  monkey = createSprite(100, 160, 20, 20);
  monkey.addAnimation("Monkey", monkeyImage);
  monkey.scale = 0.6;
  
  background = createSprite(0, 600, 600, 200);
  background = addImage("jungle", backImage);
  background.velocityX = -3;
  background.x = background.width/2;
  
  invisibleGround = createSprite(0, 170, 600, 10);
  invisibleGround.visible = false;
  
  bananaGroup = new Group();
  obstacleGroup = new Group();
  
  score = 0;
}

function draw() {
  background(220);
  
  if (background.x > 0) {
    background.x = background.width/2;
  }  
  
  if(keyDown ("space")) {
    monkey.velocityY = -10;
  }
  
  if (bananaGroup.isTouching(monkey)) {
    score = score + 2;
  }
  
  switch(score) {
    case 10 : monkey.scale = 0.12;
             break;
    case 20 : monkey.scale = 0.14;
             break;
    case 30 : monkey.scale = 0.16;
             break;
    case 40 : monkey.scale = 0.18;
             break;
    default : break;
  }
  
  if(obstacleGroup.isTouching(monkey)) {
    monkey.scale = 0.2;
  }
  
  monkey.collide(invsibleGround);
  
  spawnBanana();
  spawnObstacle();
  
  drawSprites();
  stroke("white");
  textSize(20);
  fill("white");
  text("Score: "+ score, 500, 50);
}

function spawnBanana() {
  if (frameCount % 60 === 0) {
    var banana = createSprite(600, 120, 20, 20);
    banana.velocityX = -6;
    banana.y = Math.round(random(110,150));
    banana.addImage(bananaImage);
    banana.scale = 0.6;
    
    banana.lifetime = 100;
    
    banana.depth = monkey.depth;
    monkey.depth = monkey.depth + 1;
   
    bananaGroup.add(banana);
  }
}
    
function spawnObstacle() {
  if(frameCount % 60 === 0) {
    var obstacle = createSprite(600, 170, 20, 20);
    obstacle.velocityX = -7;
    obstacle.addImage(obstacleImage);
    obstacle.scale = 0.6;
    
    obstacle.lifetime = 100;
    
    obstacleGroup.add(obstacle);
  }
}